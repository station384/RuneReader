﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HekiliHelper
{
    using System;
    using System.Drawing;
    using System.Windows;
    using System.Windows.Controls.Primitives;
    using System.Windows.Interop;
    using System.Windows.Media.Imaging;
    using System.Windows.Threading;


        public partial class MagnifierWindow : Window
        {
            private DispatcherTimer _refreshTimer;
            private double _scaleFactor = 2.0;

        public double ScaledX => this.Left * _scaleFactor;
        public double ScaledY => this.Top * _scaleFactor;
        public double ScaledWidth => this.ActualWidth * _scaleFactor;
        public double ScaledHeight => this.ActualHeight * _scaleFactor;

        public new double Left
        {
            get => base.Left;
            set => base.Left = value;
        }

        public new double Top
        {
            get => base.Top;
            set => base.Top = value;
        }

        public new double Width
        {
            get => base.Width;
            set
            {
                base.Width = value;
                MagnifyContent(); // Refresh content if the width changes.
            }
        }

        public new double Height
        {
            get => base.Height;
            set
            {
                base.Height = value;
                MagnifyContent(); // Refresh content if the height changes.
            }
        }


    


        public double ScaleFactor
        {
            get => _scaleFactor;
            set
            {
                if (value > 0)
                {
                    _scaleFactor = value;
                    MagnifyContent(); // Refresh content if the scale factor changes.
                }
            }
        }

        public MagnifierWindow()
            {
                InitializeComponent();

            this.AllowsTransparency = true;
            this.WindowStyle = WindowStyle.None;
            this.Background = System.Windows.Media.Brushes.Transparent;
            this.Topmost = true;
            this.ResizeMode = ResizeMode.CanResizeWithGrip;

            InitializeTimer();



        }

            private void InitializeTimer()
            {
                _refreshTimer = new DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(1)
                };
                _refreshTimer.Tick += RefreshTimer_Tick;
                _refreshTimer.Start();
            }

            private void RefreshTimer_Tick(object sender, EventArgs e)
            {
                MagnifyContent();
            this.InvalidateVisual();
        }

        private void MagnifyContent()
        {
            // Get the bounds of the window and the screen.
            var bounds = new System.Drawing.Rectangle((int)this.Left, (int)this.Top, (int)this.ActualWidth, (int)this.ActualHeight);
            var bmp = new Bitmap(bounds.Width, bounds.Height);

            using (var g = Graphics.FromImage(bmp))
            {
                // Capture the screen content.
                g.CopyFromScreen(new System.Drawing.Point(bounds.Left, bounds.Top), System.Drawing.Point.Empty, bounds.Size);
            }

            // Scale the bitmap up to create a magnified effect.
            var scale = 2.0; // Change this value to adjust the magnification level.
            var scaledBmp = new Bitmap(bmp, new System.Drawing.Size((int)(bounds.Width * scale), (int)(bounds.Height * scale)));

            // Convert the Bitmap to a BitmapSource for use in WPF.
            var hBitmap = scaledBmp.GetHbitmap();
            var bitmapSource = Imaging.CreateBitmapSourceFromHBitmap(
                hBitmap,
                IntPtr.Zero,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());

            // Prevent memory leak.
            DeleteObject(hBitmap);

            // Set the magnified image as the content of the window.
            var image = new System.Windows.Controls.Image { Source = bitmapSource };
            image.Source = bitmapSource;
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            MagnifyContent();
        }

        private void Window_LocationChanged(object sender, EventArgs e)
        {
            MagnifyContent();
        }

        private void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
            {
                Thumb thumb = sender as Thumb;
                if (thumb != null)
                {
                    this.Width = Math.Max(this.ActualWidth + e.HorizontalChange, thumb.Width);
                    this.Height = Math.Max(this.ActualHeight + e.VerticalChange, thumb.Height);
                }
            }

            protected override void OnClosed(EventArgs e)
            {
                base.OnClosed(e);
                if (_refreshTimer != null)
                {
                    _refreshTimer.Stop();
                    _refreshTimer.Tick -= RefreshTimer_Tick;
                    _refreshTimer = null;
                }
            }
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            // Begin dragging the window
            this.DragMove();
        }

        // PInvoke call to release the HBitmap.
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);


    }



}




